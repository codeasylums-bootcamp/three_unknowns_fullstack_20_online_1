# three_unknowns_fullstack_20_online_1

During this COVID-19 outbreak are you feeling low ? Do you want to binge on Movies but can't figure out what to watch ?
Don't worry Guys , we have created 'La Película' for you . 

# What does this do ? How can it help me ?

You can search for your favorite movies and get their IMDB ratings , find out your favorite actors and much more !!

See you in action there .

#For any queries contact on kumarsingh14abhishek@gmail.com. Happy Binge Watching !!
